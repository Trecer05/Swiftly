import 'package:flutter/material.dart';

class SidePanel extends StatelessWidget {
  const SidePanel({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.transparent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Text(
              'Ваше облако',
              style: TextStyle(
                color: Colors.white,
                fontSize: 17,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          SidePanelItem(title: 'Все файлы'),
          SidePanelItem(title: 'Последние'),
          SidePanelItem(title: 'По проектам'),
          SidePanelItem(title: 'Избранное'),
          SidePanelItem(title: 'По задачам'),
        ],
      ),
    );
  }
}

class SidePanelItem extends StatelessWidget {
  final String title;
  const SidePanelItem({required this.title, super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 20),
      child: Text(
        title,
        style: TextStyle(
          color: Colors.grey[400],
          fontSize: 15,
        ),
      ),
    );
  }
}
