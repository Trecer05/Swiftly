import 'dart:io';
import 'package:flutter/material.dart';
import 'file_model.dart';

class FileGrid extends StatelessWidget {
  final List<FileInfo> files;
  final Function(FileInfo)? onTap;

  const FileGrid({required this.files, this.onTap, super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      itemCount: files.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 5,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: 0.75, // Ключевой параметр
      ),
      itemBuilder: (_, i) => GestureDetector(
        onTap: () => onTap?.call(files[i]),
        child: FileGridItem(file: files[i]),
      ),
    );
  }
}

class FileGridItem extends StatelessWidget {
  final FileInfo file;

  const FileGridItem({required this.file, super.key});

  @override
  Widget build(BuildContext context) {
    Widget icon;

    if (file.type == 'image' && file.localPath != null) {
      icon = ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.file(
          File(file.localPath!),
          fit: BoxFit.cover,
          width: 60,
          height: 60,
          errorBuilder: (_, __, ___) =>
              Icon(Icons.image, size: 60, color: Colors.grey[400]),
        ),
      );
    } else if (file.type == 'folder') {
      icon = Icon(Icons.folder, size: 60, color: Colors.grey[400]);
    } else if (file.type == 'archive') {
      icon = Icon(Icons.archive, size: 60, color: Colors.brown[300]);
    } else {
      icon = Icon(Icons.insert_drive_file, size: 60, color: Colors.blueGrey);
    }

    return Column(
      children: [
        icon,
        SizedBox(height: 8),
        Expanded(
          child: Text(
            file.name,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }
}
