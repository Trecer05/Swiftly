import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:go_router/go_router.dart';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:open_filex/open_filex.dart';

import 'widgets/side_panel.dart';
import 'widgets/app_bar_cloud.dart';
import 'widgets/file_grid.dart';
import 'widgets/file_model.dart';

class CloudScreen extends StatefulWidget {
  const CloudScreen({super.key});

  @override
  State<CloudScreen> createState() => _CloudScreenState();
}

class _CloudScreenState extends State<CloudScreen> with WidgetsBindingObserver {
  List<FileInfo> files = [];
  List<FileInfo> _allFiles = []; // ← ПЕРЕМЕННАЯ ПОИСКА
  List<FileInfo> searchResults = []; // ← РЕЗУЛЬТАТЫ ПОИСКА
  String searchQuery = ''; // ← ТЕКУЩИЙ ЗАПРОС
  
  String? workingDir;
  List<String> directoryStack = [];

  static const _prefsKey = 'working_directory';
  static const _prefsStackKey = 'directory_stack';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initWorkingDir();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _loadWorkingDirFiles();
    }
  }

  Future<void> _initWorkingDir() async {
    final prefs = await SharedPreferences.getInstance();
    final savedPath = prefs.getString(_prefsKey);

    if (savedPath != null && await Directory(savedPath).exists()) {
      workingDir = savedPath;
    } else {
      final defaultDir = await _createDefaultDownloadFolder();
      workingDir = defaultDir.path;
      await prefs.setString(_prefsKey, workingDir!);
    }

    final savedStack = prefs.getStringList(_prefsStackKey) ?? [];
    directoryStack = List.from(savedStack);

    await _loadWorkingDirFiles();
  }

  Future<Directory> _createDefaultDownloadFolder() async {
    final baseDir = await getApplicationDocumentsDirectory();
    final defaultFolder = Directory('${baseDir.path}/YourAppDownloads');
    if (!await defaultFolder.exists()) {
      await defaultFolder.create(recursive: true);
    }
    return defaultFolder;
  }

  Future<void> _saveState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefsKey, workingDir ?? '');
    await prefs.setStringList(_prefsStackKey, directoryStack);
  }

  Future<void> _loadWorkingDirFiles() async {
    if (workingDir == null) return;

    final dir = Directory(workingDir!);
    final List<FileInfo> loadedFiles = [];

    try {
      await for (var entity in dir.list()) {
        String fileName = entity.path.split(Platform.pathSeparator).last;
        
        if (fileName.isEmpty) {
          fileName = entity.path.split(Platform.pathSeparator)[
            entity.path.split(Platform.pathSeparator).length - 2
          ];
        }

        String type = 'file';
        if (await FileSystemEntity.isDirectory(entity.path)) {
          type = 'folder';
        } else if (fileName.endsWith('.zip')) {
          type = 'archive';
        } else if (fileName.endsWith('.jpg') ||
            fileName.endsWith('.jpeg') ||
            fileName.endsWith('.png') ||
            fileName.endsWith('.svg') ||
            fileName.endsWith('.gif') ||
            fileName.endsWith('.webp') ||
            fileName.endsWith('.bmp')) {
          type = 'image';
        }
        
        loadedFiles.add(FileInfo(fileName, type, entity.path));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка: $e')),
      );
    }

    setState(() {
      files = loadedFiles;
      _allFiles = loadedFiles; // ← СОХРАНЯЕМ ВСЕ ФАЙЛЫ
    });
  }

  // ← МЕТОД ПОИСКА (ВНУТРИ КЛАССА)
  Future<void> _searchFiles(String query) async {
    if (query.isEmpty) {
      setState(() {
        searchResults = [];
        searchQuery = '';
        files = _allFiles;
      });
      return;
    }

    setState(() {
      searchQuery = query.toLowerCase();
    });

    final List<FileInfo> results = [];
    
    Future<void> searchInDirectory(String dirPath) async {
      try {
        final dir = Directory(dirPath);
        await for (var entity in dir.list(recursive: true)) {
          final fileName = entity.path.split(Platform.pathSeparator).last.toLowerCase();
          
          if (fileName.contains(searchQuery)) {
            String type = 'file';
            if (await FileSystemEntity.isDirectory(entity.path)) {
              type = 'folder';
            } else if (fileName.endsWith('.zip')) {
              type = 'archive';
            } else if (fileName.endsWith('.jpg') ||
                fileName.endsWith('.jpeg') ||
                fileName.endsWith('.png') ||
                fileName.endsWith('.svg') ||
                fileName.endsWith('.gif') ||
                fileName.endsWith('.webp') ||
                fileName.endsWith('.bmp')) {
              type = 'image';
            }
            results.add(FileInfo(fileName, type, entity.path));
          }
        }
      } catch (e) {
        print('❌ Ошибка поиска: $e');
      }
    }

    if (workingDir != null) {
      await searchInDirectory(workingDir!);
    }

    setState(() {
      searchResults = results;
      files = results;
    });
  }

  Future<void> pickWorkingDir() async {
    String? selectedDir = await FilePicker.platform.getDirectoryPath();
    if (selectedDir != null) {
      setState(() {
        workingDir = selectedDir;
        directoryStack.clear();
      });
      await _saveState();
      await _loadWorkingDirFiles();
    }
  }

  void _goBack() {
    if (directoryStack.isNotEmpty) {
      setState(() {
        workingDir = directoryStack.removeLast();
      });
      _saveState();
      _loadWorkingDirFiles();
    }
  }

  bool _canGoBack() {
    return directoryStack.isNotEmpty;
  }

  String _getCurrentDirName() {
    if (workingDir == null) return 'Файлы';
    final parts = workingDir!.split(Platform.pathSeparator);
    return parts.last.isEmpty ? parts[parts.length - 2] : parts.last;
  }

  Future<void> addFile() async {
    if (workingDir == null) {
      await _initWorkingDir();
      if (workingDir == null) return;
    }

    final action = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: Color(0xFF1a1a2e),
        elevation: 8,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: Color(0xFF3970F0), width: 1),
        ),
        title: Text(
          'Добавить файл',
          style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Выберите действие:',
          style: TextStyle(color: Colors.grey[400]),
        ),
        actions: [
          TextButton(
            onPressed: () => GoRouter.of(dialogContext).pop('new'),
            child: Text('Создать новый', style: TextStyle(color: Color(0xFF3970F0))),
          ),
          TextButton(
            onPressed: () => GoRouter.of(dialogContext).pop('upload'),
            child: Text('Загрузить свой', style: TextStyle(color: Color(0xFF3970F0))),
          ),
          TextButton(
            onPressed: () => GoRouter.of(dialogContext).pop(null),
            child: Text('Отмена', style: TextStyle(color: Colors.grey[500])),
          ),
        ],
      ),
    );

    if (action == 'new') {
      final newFileName = 'Новый файл ${DateTime.now().millisecondsSinceEpoch}.txt';
      final newFilePath = '$workingDir/$newFileName';
      final file = File(newFilePath);
      await file.create();
      setState(() {
        files.add(FileInfo(newFileName, 'file', newFilePath));
      });
    } else if (action == 'upload') {
      FilePickerResult? result = await FilePicker.platform.pickFiles();
      if (result != null) {
        final pickedFilePath = result.files.first.path!;
        final pickedFileName = result.files.first.name;
        final targetPath = '$workingDir/$pickedFileName';

        if (pickedFilePath != targetPath) {
          await File(pickedFilePath).copy(targetPath);
        }

        setState(() {
          files.add(FileInfo(pickedFileName, 'file', targetPath));
        });
      }
    }
  }

  void openFile(FileInfo file) async {
    if (file.type == 'folder') {
      directoryStack.add(workingDir!);
      setState(() {
        workingDir = file.localPath;
      });
      await _saveState();
      await _loadWorkingDirFiles();
      return;
    }
    final ext = file.name.split('.').last.toLowerCase();
    if (['jpg', 'jpeg', 'png', 'webp', 'bmp', 'gif', 'svg'].contains(ext)) {
      await _saveState();
      context.pushNamed('fileEditor', extra: file);
    } else if (ext == 'pdf' || ext == 'txt') {
      await _saveState();
      context.pushNamed('fileEditor', extra: file);
    } else if (['docx', 'doc'].contains(ext)) {
      final result = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('Открыть Word-файл'),
          content: Text(
            'Конвертация в PDF сейчас не поддерживается внутри приложения.\n'
            'Открыть документ в установленном приложении для Word?',
          ),
          actions: [
            TextButton(
              onPressed: () => GoRouter.of(context).pop('external'),
              child: Text('Открыть в Word'),
            ),
            TextButton(
              onPressed: () => GoRouter.of(context).pop(null),
              child: Text('Отмена'),
            ),
          ],
        ),
      );
      if (result == 'external' && file.localPath != null) {
        OpenFilex.open(file.localPath!);
      }
    } else {
      if (file.localPath != null) {
        OpenFilex.open(file.localPath!);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Row(
        children: [
          const SizedBox(width: 200, child: SidePanel()),
          Expanded(
            child: Column(
              children: [
                Row(
                  children: [
                    if (_canGoBack())
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: IconButton(
                          icon: Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: _goBack,
                          tooltip: 'Назад',
                        ),
                      ),
                    Expanded(
                      child: AppBarCloud(
                        title: 'Файлы',
                        currentDir: _getCurrentDirName(),
                        count: files.length,
                        onAdd: addFile,
                        onSearch: _searchFiles, // ← ПЕРЕДАЁМ МЕТОД ПОИСКА
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: IconButton(
                        icon: Icon(Icons.refresh, color: Colors.white),
                        onPressed: _loadWorkingDirFiles,
                        tooltip: 'Обновить',
                      ),
                    ),
                  ],
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30),
                    child: RefreshIndicator(
                      onRefresh: _loadWorkingDirFiles,
                      child: FileGrid(
                        files: files,
                        onTap: (file) => openFile(file),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: Icon(Icons.folder),
        label: Text(
          workingDir == null
              ? 'Выбрать папку'
              : 'Папка: ${workingDir!.split(Platform.pathSeparator).last}',
        ),
        onPressed: pickWorkingDir,
      ),
    );
  }
}

